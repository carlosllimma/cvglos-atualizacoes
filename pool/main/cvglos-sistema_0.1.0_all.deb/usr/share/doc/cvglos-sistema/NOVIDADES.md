# Novidades do cvglOS
<!-- Uma seção por versão da camada CVGL ("## 0.2.0"). A seção da versão vira as notas que a Loja mostra em
     "Atualizações". Escreva para o usuário final, em português, sem nomes internos. -->

## 0.1.0

Primeira versão do cvglOS.

- IA CVGL nativa, JEV Decisor, VPN CVGL e Guardião CVGL.
- Zero anúncios: Firefox padrão com uBlock Origin e listas de bloqueio do firewall ligadas.
- Atualizações do sistema e dos apps pela Loja, assinadas pela CVGL IT. AI.
