---
title: Sobre o cvglOS
app: about
section: apps
order: 39
keywords: versão, informações, sistema, computador, hardware
---
# Sobre o cvglOS

Mostra a versão do cvglOS, o computador (processador, memória, placa de vídeo), o kernel Linux e
como o servidor gráfico está desenhando (por GPU ou por CPU).

É a primeira coisa a olhar —ou copiar— se você for relatar um problema. Para mais detalhes do uso
do computador, abra o [Monitor](help:monitor), e para ver o que aconteceu, os [Registros](help:logs).
