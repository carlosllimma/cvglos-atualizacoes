---
title: Acerca de cvglOS
app: about
section: apps
order: 39
keywords: versión, información, sistema, equipo, hardware
---
# Acerca de cvglOS

Muestra la versión de cvglOS, el equipo (procesador, memoria, placa de video), el núcleo de Linux
y cómo está dibujando el servidor gráfico (por GPU o por CPU).

Es lo primero que conviene mirar —o copiar— si vas a informar un problema. Para más detalle del
uso del equipo, abrí el [Monitor](help:monitor), y para ver qué pasó, los [Registros](help:logs).
