---
title: About cvglOS
app: about
section: apps
order: 39
keywords: version, information, system, computer, hardware
---
# About cvglOS

Shows the cvglOS version, the computer (processor, memory, graphics card), the Linux kernel and how
the display server is drawing (GPU or CPU).

It's the first thing worth looking at —or copying— when reporting a problem. For more detail on
what the computer is doing, open [Monitor](help:monitor), and to see what happened, [Logs](help:logs).
