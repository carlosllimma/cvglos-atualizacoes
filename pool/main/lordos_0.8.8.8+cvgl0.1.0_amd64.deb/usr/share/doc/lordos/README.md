# cvglOS

O sistema operacional da **CVGL IT. AI.**, para uso pessoal e não comercial: desktop GNU/Linux rápido e seguro,
sobre Debian 13, com servidor gráfico e compositor Wayland próprios em C, interface React sobre QuickJS e a
**IA CVGL nativa**. Zero anúncios.

## O que o cvglOS traz

| | |
|---|---|
| **IA CVGL nativa** | App próprio com conversas salvas, quatro modos (Assistente, JEV Decisor, Código, Tradutor) e provedores em ordem de qualidade: IA CVGL (`cvgl-zcode`), Ollama local, llama.cpp local. Se o primeiro falha antes de responder, o próximo assume; se todos caem, avisa (kill-switch). Chave da API no cofre do sistema. |
| **JEV Decisor** | App de sistema com a rubrica da casa: melhor para o sistema, viável, fica melhor. 3xSIM executa, o resto vira PENDENTE-DONO. Exporta `decisoes_abertas.md` e `decisoes_resolvidas.md` no formato do JEV da VPS. |
| **Guardião CVGL (segurança)** | Kernel endurecido (KSPP), **sudo-rs** em Rust no lugar do sudo em C, AppArmor, verificação a cada 30 min (0,27 s, prioridade mínima) e auditoria semanal (integridade de todos os programas e Lynis). Nenhum processo fica rodando. Alertas críticos aparecem uma vez na área de trabalho e a IA CVGL explica cada achado no modo Segurança. Detalhes e pesquisa: [`docs/GUARDIAO.md`](cvgl/docs/GUARDIAO.md). |
| **Web apps da casa** | IA CVGL (web), Central CVGL e Mailbox CVGL no catálogo da Loja, cada um no próprio processo isolado do motor web do sistema. |
| **Marca e idioma** | Nome e ícones cvglOS, português do Brasil como idioma inicial, marca CVGL em todo o sistema, do boot à tela de bloqueio. |
| **Zero anúncios** | Firefox é o navegador padrão, com uBlock Origin e sem conteúdo patrocinado; listas de bloqueio de anúncios, rastreadores, golpes e malware ligadas no firewall do sistema para todos os apps. |
| **Atualização contínua** | Todo dia o sistema base é atualizado e a camada CVGL reaplicada; só publica se build, idioma, testes e não-regressão passarem. |

Além disso, o sistema traz 39 apps nativos (Arquivos, Terminal, Mail, Senhas, Monitor com
firewall visível, Loja...), apps Linux (Chromium, Firefox, GTK, Qt), pacotes Debian pela Loja, `.lpk`, 37 web apps
e o catálogo de IA (Claude Code, Claude Desktop, VS Code, Cursor, Codex CLI, goose, opencode, llama.cpp, whisper.cpp).

## Telas (ISO 0.1.0 rodando em VM)

| | |
|---|---|
| ![Boot](cvgl/docs/telas/00-boot.jpg) | ![Área de trabalho](cvgl/docs/telas/01-area-de-trabalho.jpg) |
| Boot com a marca CVGL | Área de trabalho em português, IA CVGL, JEV e VPN no Dock |
| ![IA CVGL](cvgl/docs/telas/04-ia-cvgl.jpg) | ![VPN CVGL](cvgl/docs/telas/02-vpn-cvgl.jpg) |
| IA CVGL: motor de rede pronto no sandbox do sistema | VPN CVGL no WireGuard nativo |
| ![JEV](cvgl/docs/telas/03-jev-decisor.jpg) | ![Busca](cvgl/docs/telas/05-busca-ia.jpg) |
| JEV Decisor | Busca do sistema: "Perguntar à IA CVGL" |

## VPN CVGL

1. Dock > **VPN CVGL** > **Abrir o painel** e entre com a sua conta.
2. Baixe ou copie a configuração.
3. **Da pasta Downloads** ou **Do que copiei**, confira e **Instalar no sistema** (pede a senha de administrador).
4. Ligue a chave. O estado mostra o último contato com o servidor e o tráfego.

## Usar a IA CVGL

1. Loja > instalar **IA CVGL** (pacote `cvglos-iacvgl`).
2. No app: **Provedores de IA** > IA CVGL > **Adicionar** chave (gerada em ia.cvgl.com.br > Configurações > Conta > Chaves de API).
3. Gratuito e offline: Loja > IA > **llama.cpp** (ou Ollama), baixe um modelo; o provedor local já vem configurado.
4. **Testar conexões** mostra latência e falha de cada provedor sem gastar tokens.

## Desenvolvimento

```bash
npm ci
node cvgl/rebrand.mjs          # reaplica a camada (idempotente)
npm run build
make -C cvgl/apps/iacvgl/companion test
bash cvgl/sync-upstream.sh      # traz a versão mais recente do sistema base, com todos os portões
```

Detalhes técnicos: [`docs/IA-CVGL.md`](cvgl/docs/IA-CVGL.md) e [`../AGENTS.md`](AGENTS.md).

© 2026 CVGL IT. AI. · Uso pessoal, não comercial. Licenças dos componentes em [`LICENSE`](LICENSE) e [`THIRD_PARTY.md`](THIRD_PARTY.md).
