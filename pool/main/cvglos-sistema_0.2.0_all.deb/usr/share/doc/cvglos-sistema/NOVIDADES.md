# Novidades do cvglOS
<!-- Uma seção por versão da camada CVGL ("## 0.2.0"). A seção da versão vira as notas que a Loja mostra em
     "Atualizações". Escreva para o usuário final, em português, sem nomes internos. -->

## 0.2.0

Primeira atualização do cvglOS.

- **Visual CVGL:** três papéis de parede novos (Aurora, Horizonte e Rede) na coleção CVGL, com o Aurora como padrão
  e o Horizonte na tela de login. Em telas 4K, a versão em alta resolução é usada sozinha.
- **Logo limpo:** as telas de boas-vindas, avisos e confirmações mostram o logo CVGL, sem selos.
- **Navegadores sem desvio de DNS:** Firefox e Chromium passam a usar o DNS do sistema. Assim, os bloqueios do
  firewall e o AdGuard da VPN CVGL valem também dentro do navegador.
- **Chromium sem anúncios:** o uBlock Origin Lite é instalado automaticamente no Chromium (o Firefox continua com
  o uBlock Origin completo).
- **Suas configurações:** a pasta `~/.config/cvglos` passa a levar às suas configurações do sistema.

## 0.1.0

Primeira versão do cvglOS.

- IA CVGL nativa, JEV Decisor, VPN CVGL e Guardião CVGL.
- Zero anúncios: Firefox padrão com uBlock Origin e listas de bloqueio do firewall ligadas.
- Atualizações do sistema e dos apps pela Loja, assinadas pela CVGL IT. AI.
