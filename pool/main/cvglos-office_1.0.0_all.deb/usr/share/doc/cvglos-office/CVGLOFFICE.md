# cvglOffice e CVGL Studio

Apps de produtividade e áudio do cvglOS, feitos a partir dos apps **abertos** da família storytold
(MIT OR Apache-2.0, escritos do zero em Rust) com a marca CVGL aplicada de forma reproduzível.

| App no cvglOS | Comando | Origem (versão fixada em `cvgl/office/apps.json`) | Português |
|---|---|---|---|
| cvglOffice Texto | `cvgl-texto` / `cvgl-texto-cli` | WordCraft | completo (catálogo craft-i18n) |
| cvglOffice PDF | `cvgl-pdf` / `cvgl-pdf-cli` | PdfCraft | completo (catálogo craft-i18n) |
| CVGL Studio | `cvgl-studio` / `cvgl-studio-cli` | SoundCraft (o equivalente aberto ao Pro Tools) | completo (tradução embutida; padrão PT-BR) |
| CVGL Foto | `cvgl-foto` / `cvgl-foto-cli` | PhotoCraft (edição de imagens, PSD) | completo (catálogo craft-i18n) |
| CVGL Vetor | `cvgl-vetor` / `cvgl-vetor-cli` | VectorCraft (ilustração vetorial, SVG) | completo (catálogo dentro do app) |

## Como é feito

- `cvgl/office/marca.py` exporta o código na versão fixada e aplica: nome do app em textos e catálogos (as duas
  colunas, para a busca da tradução continuar casando), troca da marca e dos links de origem (site, Discord) pela
  IA CVGL, ícones CVGL próprios, abas de créditos de origem removidas do "Sobre", atualização própria pelo GitHub
  de origem desligada (o cvglOS atualiza pela Loja) e português como padrão. Falha alto se um trecho esperado
  sumir do upstream. Só regrava arquivos que mudaram (recompilação incremental).
- `cvgl/office/compilar.sh <cvglos-office|cvglos-studio> <saida>` baixa, aplica a marca, compila e empacota
  (`cvgl/pkg/mkdeb-craft.sh`). No release (`cvgl-release.yml`) roda no runner Ubuntu 24.04 (glibc 2.39, roda no
  Debian 13). Os dois pacotes entram em `cvgl/sistema/apps.json`, então chegam pela atualização do sistema.
- Licenças e avisos de cada componente: `/usr/share/doc/cvglos-office/` e `/usr/share/doc/cvglos-studio/`
  (exigência MIT/Apache; não aparecem em tela). O nome e os logos ArtCraft são marca registrada da origem e não
  são usados.
- Documentos do Word, ODT e RTF abrem no cvglOffice Texto (`cvgl/base/etc/xdg/mimeapps.list`); o PDF continua no
  leitor nativo, mais leve, com o cvglOffice PDF em "Abrir com".

## Maturidade (aviso honesto)

Os apps de origem estão em desenvolvimento acelerado; PdfCraft e PhotoCraft se declaram "alfa inicial". Cada versão
fixada em `apps.json` é testada na VM antes de ir para o canal; versões novas entram por atualização do cvglOS.

## Pacotes

Um pacote por app (`cvglos-texto`, `cvglos-pdf`, `cvglos-studio`, `cvglos-foto`, `cvglos-vetor`): cada atualização
baixa só o que mudou e nenhum arquivo passa de 100 MB. `cvglos-office` reúne Texto e PDF e traz:

- `cvgl-converter <entrada> <saida>`: converte documentos (docx, odt, rtf, html, md, tex, txt -> pdf, docx...) e
  imagens (psd, png, jpg, tif, webp) sem abrir janela; o formato vem da extensão da saída.
- `/usr/share/cvglos/mcp.json`: os cinco apps como servidores MCP (stdio), para um agente de IA dirigi-los
  (`cvgl-texto-cli mcp` etc.; conferido: 18, 212, 17 e 26 ferramentas em Texto, PDF, Studio e Foto).

Os comandos internos de origem (`wordcraft`, `photocraft`, `vectorcraft`...) existem como atalhos: é por eles que um
app encontra o outro (o Foto abre vetores no Vetor).

## Resolvido na 0.3.0

- Comentário do arquivo `.tex` exportado: troca de mesmo tamanho no binário (`binario` em `apps.json`; o build para
  se o trecho sumir da biblioteca externa).
- Modelos de exemplo do Texto (manual, carta, currículo, relatório) em português (`arquivo_frases`).
- "AudioSuite" do Studio -> "Processamento" em todo o código e no catálogo de menus (`palavras`, `arquivos_texto`).

## Jogos CVGL

`cvglos-jogos` (`cvgl/jogos/jogos.json`, `cvgl/pkg/mkdeb-jogos.sh`): coleção opcional de oito jogos livres do Debian
(343 MB), em destaque na página inicial da Loja (`cvgl/jogos/featured.json` + `banner.png`, assinados no canal;
o servidor aceita a vitrine do repositório de origem "cvglOS").

## Fora (com motivo)

- **Planilhas (GridCraft) e Apresentações (DeckCraft):** sem tradução para o português (Planilhas parcial,
  Apresentações só inglês e sem suporte a idiomas no código). Os próprios autores estimam 100-165 h só para as
  Planilhas; não cabe numa sessão e não entra com texto em inglês.
- **Música por IA no Studio (ACE-Step 1.5, MIT):** exige placa de vídeo e alguns GB de modelo; não há GPU nem
  disco na máquina de build para testar, e código não testado não entra.
- **Modelo do Suno:** fechado; os termos proíbem extração e engenharia reversa e não há API pública
  (só programa de parceiros). Música por IA no Studio: com modelo aberto (ACE-Step 1.5, MIT) rodando local.
- **Jogos do Ported2Browser:** o diretório mistura projetos abertos, demos oficiais e ports de jogos comerciais
  (ROMs, recompilações). Só os de licença aberta podem ser incluídos; o site está fora da rede da sessão.
